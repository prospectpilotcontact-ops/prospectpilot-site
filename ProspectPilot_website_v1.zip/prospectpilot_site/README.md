# ProspectPilot — static launch website

## Included
- `index.html` — English landing page, pricing, service details and enquiry form.
- `sample-report.html` — five-business illustrative London sample with one sample outreach draft.
- `privacy.html` — initial privacy notice, to be reviewed before launch.
- `styles.css` — responsive styling.
- `script.js` — mailto-based enquiry preparation and form validation.

## How the enquiry works
This site **does not** collect or store leads server-side. The visitor fills the form and presses **Prepare my request**. Their email app opens with a prepared message to `prospectpilot.contact@gmail.com`; they must press **Send** in their email app. If no mail app is configured, the visitor can use the visible email link. No claim of a successful submission is made by the website.

## Preview locally
Open `index.html` in a browser, or run `python -m http.server 8000` in this folder and visit `http://localhost:8000`.

## Free hosting option: GitHub Pages
1. Create a GitHub account/repository, e.g. `prospectpilot-site`, set the repository **Public** for free GitHub Pages availability.
2. Upload the five website files to the repository root.
3. Under **Settings → Pages**, select **Deploy from a branch**, `main`, `/ (root)`; save.
4. GitHub will show a `https://USERNAME.github.io/prospectpilot-site/` URL after deployment. No domain purchase is necessary. This requires the owner's GitHub account action and publishes the site publicly.

Alternative: Netlify static deploy via manual drag-and-drop, subject to the provider's current free-plan terms.

## Before public commercial launch
- Verify trade name, legal entity details, taxes, and relevant jurisdiction requirements.
- Obtain and verify professional mailing address if required for marketing emails; do not publish a guessed address.
- Have privacy and anti-spam practices reviewed for intended markets; do not assume publicly listed emails grant permission to send unsolicited marketing.
- Review and verify all sample claims, links and pricing.
- Consider a hosted form provider (with spam protection, privacy consent, and retention controls) if automated lead collection is required.
- Review Google Fonts third-party requests and self-host or use system fonts if needed.
- Test on mobile and with several email clients before sharing widely.

No paid service or external account was created, and no website was deployed.
