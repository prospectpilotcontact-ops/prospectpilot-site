'use strict';
document.getElementById('year').textContent = new Date().getFullYear();
const form = document.getElementById('leadForm');
form.addEventListener('submit', function(event) {
  event.preventDefault();
  const status = document.getElementById('formStatus');
  if (!form.reportValidity()) { status.textContent = 'Please complete all required fields and accept the notice.'; return; }
  const fields = ['name','email','company','market','notes'];
  const values = Object.fromEntries(fields.map(id => [id, document.getElementById(id).value.trim()]));
  if (!values.name || !values.email || !values.company || !values.market) { status.textContent = 'Please complete all required fields.'; return; }
  const subject = 'ProspectPilot Starter Pilot enquiry — ' + values.company;
  const body = ['Hello ProspectPilot,','','I would like to enquire about the CA$149 Starter Pilot.','','Name: '+values.name,'Work email: '+values.email,'Company: '+values.company,'Target industry and location: '+values.market,'Services / notes: '+(values.notes||'Not provided'),'','Please let me know if my request is a good fit.','','Sent using the ProspectPilot website enquiry form.'].join('\n');
  status.textContent = 'Your email app should open with a prepared request. Please press Send in your email app to complete it. If nothing opens, email prospectpilot.contact@gmail.com directly.';
  window.location.href = 'mailto:prospectpilot.contact@gmail.com?subject='+encodeURIComponent(subject)+'&body='+encodeURIComponent(body);
});
